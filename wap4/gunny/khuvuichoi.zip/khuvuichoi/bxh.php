<?php
define('_IN_JOHNCMS', 1);
$headmod = 'users';
require '../incfiles/core.php';
$textl = 'Bảng Xếp Hạng';
require '../incfiles/head.php';

echo'<div class="main-xmenu" id="action">
<img src="/icon/banner/bxh.png" class="wow zoomIn">';
if(!isset($_GET['ngay'])){
echo css(phdr,'TOP XU KHÓA');
$req = mysql_query("SELECT `id`,`tienxu` FROM `users` WHERE `tienxu` > 0 ORDER BY `tienxu` DESC LIMIT 5");
$i = 1; $delay = 0;
while ($res = mysql_fetch_array($req)) {
	$delay = $delay+0.1;
echo '<div class="wow fadeInUp" data-wow-delay="'.$delay.'s">'.css(menu,'<div class="newsxx"><table style="width:100%"><tbody><tr><td>
<img src="'.$home.'/face.php?u='.$res['id'].'" class="avatar_vina xavt"/>
<a href="/account/'.$res['id'].'"><b>'.nick($res['id']).'</b></a><br/>
'.money($res['tienxu'],'xk').'</td>
<td class="right">
'.($i<=3 ? '<img src="/icon/no'.$i.'.png">' : '').'
</td>
</tr></tbody></table>
</div>').'</div>';
$i++;
}
echo'</div>';
$i = 1; $delay = 0;
echo css(phdr,'TOP XU');
$req = mysql_query("SELECT `id`,`vinaxu` FROM `users` WHERE `vinaxu`>'0' ORDER BY `vinaxu` DESC LIMIT 5");
while ($res = mysql_fetch_array($req)) {
	$delay = $delay+0.1;
echo '<div class="wow fadeInUp" data-wow-delay="'.$delay.'s">'.css(menu,'<div class="newsxx"><table style="width:100%"><tbody><tr><td>
<img src="'.$home.'/face.php?u='.$res['id'].'" class="avatar_vina xavt"/>
<a href="/account/'.$res['id'].'"><b>'.nick($res['id']).'</b></a><br/>
'.money($res['vinaxu'],'xu').'</td>
<td class="right">'.($i<=3 ? '<img src="/icon/no'.$i.'.png">' : '').'</td>
</tr></tbody></table>
</div>').'</div>';
$i++;
}
echo'<div class="main-xmenu">';
$i = 1; $delay = 0;
echo css(phdr,'TOP SỨC MẠNH');
$req = mysql_query("SELECT `user_id` FROM `nhanvat` ORDER BY `sucmanhgoc` DESC LIMIT 5");
while ($res = mysql_fetch_array($req)) {
$thongtindoithu = mysql_fetch_array(mysql_query("SELECT `sucmanhgoc` FROM `nhanvat` WHERE `user_id`='".$res['user_id']."'"));
	$delay = $delay+0.1;
echo '<div class="wow fadeInUp" data-wow-delay="'.$delay.'s">'.css(menu,'<div class="newsxx"><table style="width:100%"><tbody><tr><td>
<img src="'.$home.'/face.php?u='.$res['user_id'].'" class="avatar_vina xavt"/>
<a href="/account/'.$res['id'].'"><b>'.nick($res['user_id']).'</b></a><br/>
'.money($thongtindoithu['sucmanhgoc'],'sm').'</td>
<td class="right">'.($i<=3 ? '<img src="/icon/no'.$i.'.png">' : '').'</td>
</tr></tbody></table>
</div>').'</div>';
$i++;
}
echo'</div>';
$i = 1; $delay = 0;
echo css(phdr,'TOP CHỐNG CHỊU');
$req = mysql_query("SELECT `user_id` FROM `nhanvat` ORDER BY `hpfull` DESC LIMIT 5");
while ($res = mysql_fetch_array($req)) {
$thongtindoithu = mysql_fetch_array(mysql_query("SELECT `hpfull` FROM `nhanvat` WHERE `user_id`='".$res['user_id']."'"));
	$delay = $delay+0.1;
echo '<div class="wow fadeInUp" data-wow-delay="'.$delay.'s">'.css(menu,'<div class="newsxx"><table style="width:100%"><tbody><tr><td>
<img src="'.$home.'/face.php?u='.$res['user_id'].'" class="avatar_vina xavt"/>
<a href="/account/'.$res['user_id'].'"><b>'.nick($res['user_id']).'</b></a><br/>
'.money($thongtindoithu['hpfull'],'hp').'</td>
<td class="right">'.($i<=3 ? '<img src="/icon/no'.$i.'.png">' : '').'</td>
</tr></tbody></table>
</div>').'</div>';
$i++;
}
$i = 1; $delay = 0;
echo css(phdr,'TOP SINH TỒN');
$req = mysql_query("SELECT `id`,`crep` FROM `users` WHERE `crep`>'0' ORDER BY `crep` DESC LIMIT 5");
while ($res = mysql_fetch_array($req)) {
	$delay = $delay+0.1;
echo '<div class="wow fadeInUp" data-wow-delay="'.$delay.'s">'.css(menu,'<div class="newsxx"><table style="width:100%"><tbody><tr><td>
<img src="'.$home.'/face.php?u='.$res['id'].'" class="avatar_vina xavt"/>
<a href="/account/'.$res['id'].'"><b>'.nick($res['id']).'</b></a><br/>
Quái tiêu diệt: '.$res['crep'].'</td>
<td class="right">'.($i<=3 ? '<img src="/icon/no'.$i.'.png">' : '').'</td>
</tr></tbody></table>
</div>').'</div>';
$i++;
}

} else {
	echo css(phdr,'TOP NGƯ DÂN HÔM NAY');
$req = mysql_query("SELECT `id`,`cahomnay` FROM `users` WHERE `cahomnay` > 0 ORDER BY `cahomnay` DESC LIMIT 5");
$i = 1; $delay = 0;
while ($res = mysql_fetch_array($req)) {
	$delay = $delay+0.1;
echo '<div class="wow fadeInUp" data-wow-delay="'.$delay.'s">'.css(menu,'<div class="newsxx"><table style="width:100%"><tbody><tr><td>
<img src="'.$home.'/face.php?u='.$res['id'].'" class="avatar_vina xavt"/>
<a href="/account/'.$res['id'].'"><b>'.nick($res['id']).'</b></a><br/>
<img src="/icon/ca.png"> '.$res['cahomnay'].'</td>
<td class="right">
'.($i<=3 ? '<img src="/icon/no'.$i.'.png">' : '').'
</td>
</tr></tbody></table>
</div>').'</div>';
$i++;
}
}
echo'</div>';
require '../incfiles/end.php';